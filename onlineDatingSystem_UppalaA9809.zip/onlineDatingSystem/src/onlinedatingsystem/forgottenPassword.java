/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onlinedatingsystem;
import java.util.*;
import java.sql.*;
import java.text.*;

/**
 *
 * @author Ashish Uppala
 */
public class forgottenPassword 
{
 public static void forgottenPassword()
 {
      Scanner input = new Scanner(System.in);
      System.out.println("***Menu***");
      System.out.println("1: if you are New user");
      System.out.println("2: if you are Old User");   
      String choice = input.next();
      
      if(choice.equals("1"))
      {
          System.out.println("******you need to sign up*****");
         OnlineDatingSystem.signUp();
      }
      else if(choice.equals("2"))
      { 
          System.out.println("1: forgot password");
          System.out.println("2: would try login again??");
          String loginchoice = input.next();
          
          if(loginchoice.equals("1"))
              
          {
          oldUser();
          }
          else if(loginchoice.equals("2"))
                  {
                      OnlineDatingSystem.login();
                  }
          else
          {
              System.out.println("***Directing to main menu***");
              OnlineDatingSystem.login();
          }
      }
      else
      {
          System.out.println("Please enter correct choice");
          OnlineDatingSystem.login();
      }
      
}   
 public static void  newUser()
 { 
     Scanner input = new Scanner(System.in);
      System.out.println("***Please enter the following details to retrieve your password****");
      System.out.println("please enter your name");
      String name = input.next();
      System.out.println("Please enter your first security question");
      input.nextLine();
      String question1 = input.nextLine();
      System.out.println("Please enter your answer for it...(Please enter answer max of 8 characters...)");
      String answer1 = input.nextLine();
      System.out.println("Please enter your second security question");
   
      String question2 = input.nextLine();
      System.out.println("Please enter your answer for it...(Please enter answer max of 8 characters...)");
      String answer2 = input.nextLine();
      
      final String URL = "jdbc:mysql://mis-sql.uhcl.edu/uppalaa9809";
       Connection conn = null;
       ResultSet rs = null;
       Statement stat = null;
       
       try
       {
           conn = DriverManager.getConnection(URL, "uppalaa9809", "1502561");
           stat = conn.createStatement();
           rs = stat.executeQuery("select * from onlinedating_forgotpassword");
           int r = stat.executeUpdate(" Insert into onlinedating_forgotpassword values('" +name+ "','" +question1+ "', '"+answer1+"', '"+question2+"', '"+answer2+"' )");
           System.out.println("***your security information is stored***");
          System.out.println("***you have successfully signed up***");
           
           
            loginAfterMenu.menu();
       }
       catch(SQLException e)
               {
                   e.printStackTrace();
               }
       finally
       {
           try
           {
               conn.close();
               rs.close();
               stat.close();
               
           }
           catch(SQLException e)
                   {
                       e.printStackTrace();
                   }
       }
 }
 
 public static void oldUser()
 {
     Scanner input = new Scanner(System.in);
   
     
     
        final String URL = "jdbc:mysql://mis-sql.uhcl.edu/uppalaa9809";
     Connection conn =null;
     ResultSet rs = null;
     ResultSet rs1 = null;
     Statement stat = null;
     Statement stat1 = null;
     
     try
     {
      System.out.println("Please enter the name with which you have signedUp");
     String nameSearch = input.next();
        // System.out.println(nameSearch);
    System.out.println(nameSearch);
           conn = DriverManager.getConnection(URL, "uppalaa9809", "1502561");
         stat = conn.createStatement();
         stat1 = conn.createStatement();
         rs = stat.executeQuery("select * from onlinedating_forgotpassword where name ='" +nameSearch+ "'");
         rs1 = stat1.executeQuery("Select * from onlinedating_user" );
         while(rs.next())
         { 
             if(rs.getString("name").equals(nameSearch))
             {
                 System.out.println( "Question_01: " + " " + rs.getString("question1"));
                 System.out.println("Please enter the answer for this question");
                 String answer_01 = input.next();
                 if(rs.getString("answer1").equals(answer_01))
                 {
                     System.out.println("Question_02: " + " " + rs.getString("question2"));
                     System.out.println("Please enter the answer for this question");
                     String answer_02 = input.next();
                     
                     if(rs.getString("answer2").equals(answer_02))
                     {
                         System.out.println("*****MENU******");
                         System.out.println("1: To retrieve old Password");
            
                            
                         String passwordRetrieve = input.next();
                         
                         if(passwordRetrieve.equals("1"))
                     {
//                             if(rs1.getString("name").equals(nameSearch))
//                             System.out.println("Your Password is: " + " " + rs1.getString("password"));

                          
                             System.out.println("enter your name once again");
                             String name = input.next();
                             while(rs1.next())
                             {
                             if(rs1.getString("name").equals(name))
                             {
                                 System.out.println(rs1.getString("password"));
                                                          System.out.println("***your password is retreived***");
                                               System.out.println("***returning to login menu***");
                                               OnlineDatingSystem.login();
                             }
                             }
                         }
                         
                         else
                         {
                             System.out.println("returning to previous menu");
                         }
                         
                         
                         
                         
                     }
                     else
                     {
                          System.out.println("***WRONG ANSWER***");
                     System.out.println("**going back to previous menu**");
                     forgottenPassword.forgottenPassword();
                     }
                 }
                 else
                 {
                     System.out.println("***WRONG ANSWER1***");
                     System.out.println("**going back to previous menu**");
                     forgottenPassword.forgottenPassword();
                 }
             }
             else
             {
                  System.out.println("***WRONG Name2***");
                     System.out.println("**going back to previous menu**");
                     forgottenPassword.forgottenPassword();
             }
         }
     }
     catch(SQLException e)
     {
         e.printStackTrace();
     }
     finally
     {
         try
         {
             conn.close();
             rs.close();
             rs1.close();
             stat.close();
             stat1.close();
             
         }
         catch(SQLException e)
                 {
                     e.printStackTrace();
                 }
     }
 }
}
