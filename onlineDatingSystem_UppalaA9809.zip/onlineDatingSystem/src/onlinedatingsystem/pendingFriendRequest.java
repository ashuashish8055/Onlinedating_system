/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onlinedatingsystem;
import java.util.*;
import java.sql.*;
import java.text.*;
/**
 *
 * @author Ashish Uppala
 */
public class pendingFriendRequest {
    public static String SenderId="";
    
        
    
    public static void pendingFriendRequest()
    {
       Scanner input = new Scanner(System.in);
        System.out.println("***Pending FriendRequests****");
        String dateAndTime = DateAndTime.DateTime();
        final String URL = "jdbc:mysql://mis-sql.uhcl.edu/uppalaa9809";
        Connection conn = null;
        ResultSet rs = null;
        //ResultSet rs1 = null;
        Statement stat = null;
        //Statement stat1 =null;
        
        try
        {
            conn = DriverManager.getConnection(URL, "uppalaa9809", "1502561" );
            stat = conn.createStatement();
            //stat1 = conn.createStatement();
            rs = stat.executeQuery("select distinct senderId from onlinedating_friendrequest");
            System.out.println("The pending requests are:");
            while(rs.next())
            {
                System.out.println(rs.getString("senderId"));
                SenderId=rs.getString("senderId");
            }
            
            boolean add = false;
            while(add == false)
            {
                System.out.println("Enter the Id from your pending requests to add to your friend's list ");
                String addId = input.next();
                System.out.println("Do you want to accept or reject request");
                String Status = input.next();
                if(Status.equals("accept"))
                {
                    int r = stat.executeUpdate("Update onlinedating_friendrequest set Status= 'accept',"
                            + " dateAndTime= '"+dateAndTime+"' where senderId= '"+addId+"' and  "
                            + "receiverId= '"+OnlineDatingSystem.getLoginId()+"'");
                    int r1 = stat.executeUpdate("Insert into onlinedating_friendslist values('" + addId +"', '" 
                                                       + OnlineDatingSystem.getLoginId() +"')");
                    int r2 = stat.executeUpdate("Insert into onlinedating_friendslist values('" + OnlineDatingSystem.getLoginId() +"', '"
                                                + addId +"')");
          
                }
                else if(Status.equals("reject"))
                {
                   int r = stat.executeUpdate("Update onlinedating_friendrequest set Status= 'reject', dateAndTime= '"+dateAndTime+"' where senderId= '"+addId+"' and "
                                + "receiverId= '"+OnlineDatingSystem.getLoginId()+"'") ;
                   
                }       
                else
                {
                    System.out.println("Please enter correct choice");
                }
                System.out.println("Do you need to add more friends to your list or not (Y/N)");
                String addingChoice = input.next();
                if(addingChoice.equals("N"))
                {
                    System.out.println("You have choosen not to add friends to your list and returning to your menu ");
                    loginAfterMenu.menu();
                    add = true;
                    
                }
                else if(addingChoice.equals("Y"))
                {
                    
                }
                else
                {
                    System.out.println("You have not entered correct choice so returning to your menu");
                    loginAfterMenu.menu();
                }
            }
        }
        catch(SQLException e)
                {
                    e.printStackTrace();
                }
        finally
        {
            try
            {
                conn.close();
                rs.close();
                //rs1.close();
                stat.close();
                //stat1.close();
            }
            catch(SQLException e)
                    {
                        e.printStackTrace();
                    }
        }
    }

    public static String getSenderId() {
        return SenderId;
    }
    
}
