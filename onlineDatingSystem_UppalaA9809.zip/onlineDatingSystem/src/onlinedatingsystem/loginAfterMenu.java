/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onlinedatingsystem;
import java.util.*;

/**
 *
 * @author Ashish Uppala
 */
public class loginAfterMenu 
{
  public static void menu()
  {
      Scanner input = new Scanner(System.in);
      String name = OnlineDatingSystem.getLoginName();
      System.out.println();
      System.out.println("***Welcome to your Page "+name + "***");   
      System.out.println();
      System.out.println("***Menu***");
      System.out.println("1: search friends");
      System.out.println("2: your friends list");
      System.out.println("3: pending freind requests");   
      System.out.println("4: messages");
      System.out.println("5: logout");
     System.out.println("6: profileView");
      
      String option = input.next();
      if(option.equals("1"))
      {
          //searching friends
          searchingFriends.SearchingFriends();
      }
      else if(option.equals("2"))
      {
          //your friend's list
          FriendsList.FriendsList();
      }
      else if(option.equals("3"))
      {
          //pending friend's requests
          pendingFriendRequest.pendingFriendRequest();
      }
      else if(option.equals("4"))
      {
          //messages
          Messages.Messages();
      }
      else if(option.equals("5"))
      {
          //logout
          
          logout.logout();
      }
      else if(option.equals("6"))
      {
          //profileview
          
          profileView.profileView();
      }

  }
}
