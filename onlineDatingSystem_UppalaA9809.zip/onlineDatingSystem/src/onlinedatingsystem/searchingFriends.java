/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onlinedatingsystem;
import java.util.*;
import java.sql.*;
import java.text.*;
/**
 *
 * @author Ashish Uppala
 */
public class searchingFriends 
{

  public static void   SearchingFriends()
  {
      Scanner input = new Scanner(System.in);
      System.out.println("***Welcome to the search, Please select your crieteria based on following***");
      System.out.println("1: Gender");
      System.out.println("2: Age");
      System.out.println("3: city");
      System.out.println("4: Interest");
      System.out.println("5: return to profile menu");
      String choice = input.next();
      String senderId = OnlineDatingSystem.getLoginId();
       String Time = DateAndTime.DateTime();
          String receiverId ="";
        final String  URL = "jdbc:mysql://mis-sql.uhcl.edu/uppalaa9809";    
        Connection conn = null;
        ResultSet rs =null;
        ResultSet rs1 = null;
      
        Statement stat = null;
        Statement stat1 = null;
        Statement stat2 = null;
        try
        {
            conn = DriverManager.getConnection(URL, "uppalaa9809","1502561");
            stat = conn.createStatement();
            stat1 = conn.createStatement();
            stat2 = conn.createStatement();
          if(choice.equals("1"))
      {
          System.out.println("Please enter gender M/F to search");
          String gender = input.next();
          rs = stat.executeQuery("select name from onlinedating_user where gender='" + gender +"'");
          while(rs.next())
          {
              System.out.println(rs.getString("name"));
          }
         
          System.out.println("enter the name to add to your friend's list");
          String newFriend = input.next();
           
          
          System.out.println("Do you want to view the profile (Y/N)");
          String viewChoice=input.next();
          if(viewChoice.equals("Y"))
          {
              //System.out.println("welcome to"+ newFriend +"profile");
              profileView.profileView();
          }
          else if(viewChoice.equals("N"))
          {
              System.out.println("1:add Directly");
              System.out.println("2:Returning to menu");
              String c1 = input.next();
              if(c1.equals("2"))
              {
              searchingFriends.SearchingFriends();
              }
              else if(c1.equals("1"))
              {
          rs1 = stat1.executeQuery("select userId from onlinedating_user where name='" + newFriend +"'");
          while(rs1.next())
          {
              System.out.println(rs1.getString("userId"));
              receiverId = rs1.getString("userId");
          }
          
          int r = stat.executeUpdate("Insert into onlinedating_friendrequest values('" + senderId + "', '" + receiverId + "', 'Pending','" + Time + "', 'genderbased')");
          System.out.println("**Friend Request sent and status is Pending**");
          }
          }
          else
          {
              System.out.println("enter correct choice returning to profile menu");
              loginAfterMenu.menu();
          }
      }  
          else if(choice.equals("2"))
          {
              System.out.println("Please enter the age limits to search");
              String ageSearch = input.next();
              if(ageSearch.contains(","))
              {
                  String number[] = ageSearch.split(",");
                  int num1 = Integer.parseInt(number[0]);
                  int num2 = Integer.parseInt(number[1]);
                  rs = stat.executeQuery("select name from onlinedating_user where age between " +num1+" and "+num2 );
                   while(rs.next())
                  {
                    System.out.println(rs.getString("name"));
                   }
                System.out.println("enter the name to add to your friend's list");
                String newFriend = input.next();
                
                  
          System.out.println("Do you want to view the profile (Y/N)");
          String viewChoice=input.next();
          if(viewChoice.equals("Y"))
          {
              //System.out.println("welcome to"+ newFriend +"profile");
              profileView.profileView();
          }
          else if(viewChoice.equals("N"))
          {
              System.out.println("1:add Directly");
              System.out.println("2:Returning to menu");
              String c1 = input.next();
              if(c1.equals("2"))
              {
              searchingFriends.SearchingFriends();
              }
              else if(c1.equals("1"))
              {
                rs1 = stat1.executeQuery("select userId from onlinedating_user where name='" + newFriend +"'");
                while(rs1.next())
                {
                 System.out.println(rs1.getString("userId"));
                 receiverId = rs1.getString("userId");
                  }
              int r = stat.executeUpdate("Insert into onlinedating_friendrequest values('" + senderId + "', '" + receiverId + "', 'Pending', '" + Time + "', 'agebased')");
              System.out.println("**Friend Request sent and status is Pending**");
              }
              }
          else
          {
              System.out.println("enter correct choice returning to profile menu");
              loginAfterMenu.menu();
          }
              }
          }
          else if(choice.equals("3"))
          {
              System.out.println("Please enter your city to search ");
              String citySearch = input.next();
              rs = stat.executeQuery("select name from onlinedating_user where city='" + citySearch +"'");
              while(rs.next())
              {
                  System.out.println(rs.getString("name"));
              }
                System.out.println("enter the name to add to your friend's list");
                String newFriend = input.next();
                
                
                 System.out.println("Do you want to view the profile (Y/N)");
          String viewChoice=input.next();
          if(viewChoice.equals("Y"))
          {
              //System.out.println("welcome to"+ newFriend +"profile");
              profileView.profileView();
          }
          else if(viewChoice.equals("N"))
          {
              System.out.println("1:add Directly");
              System.out.println("2:Returning to menu");
              String c1 = input.next();
              if(c1.equals("2"))
              {
              searchingFriends.SearchingFriends();
              }
              else if(c1.equals("1"))
              {
                rs1 = stat1.executeQuery("select userId from onlinedating_user where name='" + newFriend +"'");
                while(rs1.next())
                {
                    System.out.println(rs1.getString("userId"));
                    receiverId = rs1.getString("userId");
                }
                int r = stat.executeUpdate("Insert into onlinedating_friendrequest values('" + senderId + "', '" + receiverId + "', 'Pending', '" + Time + "', 'citybased')");
                System.out.println("**Friend Request sent and status is Pending**");
          }
          }
           else
          {
              System.out.println("enter correct choice returning to profile menu");
              loginAfterMenu.menu();
          }
          }
          else if(choice.equals("4"))
          {
              System.out.println("Please enter your interest to search");
              String interestSearch = input.next();
              rs = stat.executeQuery("select name from onlinedating_user where interest1='"+interestSearch+"' or interest2='"+interestSearch+"' or interest3='" + interestSearch +"'");
              while(rs.next())
              {
                  System.out.println(rs.getString("name"));
           
              }
          
             System.out.println("enter the name to add to your friend's list");
             String newFriend = input.next();
             
             
                 System.out.println("Do you want to view the profile (Y/N)");
          String viewChoice=input.next();
          if(viewChoice.equals("Y"))
          {
            //  System.out.println("welcome to"+ newFriend +"profile");
              profileView.profileView();
          }
          else if(viewChoice.equals("N"))
          {
              System.out.println("1:add Directly");
              System.out.println("2:Returning to menu");
              String c1 = input.next();
              if(c1.equals("2"))
              {
              searchingFriends.SearchingFriends();
              }
              else if(c1.equals("1"))
              {
             rs1 = stat1.executeQuery("select userId from onlinedating_user where name='" + newFriend +"'");
                while(rs1.next())
                {
                    System.out.println(rs1.getString("userId"));
                          receiverId = rs1.getString("userId");
                }
                int r = stat.executeUpdate("Insert into onlinedating_friendrequest values('" + senderId +"', '" + receiverId + "', 'Pending', '" + Time + "', 'interestbased')");
                System.out.println("**Friend Request sent and status is Pending**");
          }
        }
          else
          {
              System.out.println("enter correct choice returning to profile menu");
              loginAfterMenu.menu();
          }
          }
          else if(choice.equals("5"))
          {
              loginAfterMenu.menu();
          }
          else
          {
              System.out.println("Please enter correct choice returning to menu");
              searchingFriends.SearchingFriends();
          }
        }
        
        catch(SQLException e)
                {
                    e.printStackTrace();
                }
       finally
        {
            try
            {
                conn.close();
                rs.close();
                rs1.close();
               
                stat.close();
                stat1.close();
                stat2.close();
            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }
        }
 
  }

    
}
