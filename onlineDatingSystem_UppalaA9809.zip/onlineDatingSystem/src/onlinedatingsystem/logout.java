/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onlinedatingsystem;
import java.sql.*;
import java.util.*;
/**
 *
 * @author Ashish Uppala
 */
public class logout 
{
    public static void logout()
    {
        String logoutTime = DateAndTime.DateTime();
        final String URL = "jdbc:mysql://mis-sql.uhcl.edu/uppalaa9809";
        Connection conn = null;
        Statement  stat = null;
        ResultSet  rs = null;
        String getId = OnlineDatingSystem.getLoginId();
        String getName = OnlineDatingSystem.getLoginName();
        
        try
        {
            conn = DriverManager.getConnection(URL, "uppalaa9809","1502561");
            stat = conn.createStatement();
            rs = stat.executeQuery("select * from onlinedating_user where userId = '"+ getId + "'");
            while(rs.next())
            {
                int r = stat.executeUpdate("Update onlinedating_user set logoffTime= '"+ logoutTime + "'");
                break;
            }
            System.out.println("***you have logged out successfully***");
            System.out.println();
            System.out.println("1: To Refresh Login again");
            System.out.println("2: To exit onlineDating system");
            Scanner input = new Scanner(System.in);
            String logstatus = input.next();
            while(!logstatus.equals("2"))
            {
            if(logstatus.equals("1"))
            {
                OnlineDatingSystem.login();
            }
            else
            {
                System.out.println("Invalid entry  you need to press 1 to login again");
                break;
            }
            }
        }
        catch(SQLException e)
                {
                   e.printStackTrace();
                }
        finally
        {
            try
            {
                 conn.close();
                 stat.close();
                 rs.close();
            }
            catch(SQLException e)
                    {
                        e.printStackTrace();
                    }
        }
    }
}
