/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onlinedatingsystem;
import java.sql.*;
import java.util.*;
/**
 *
 * @author Ashish Uppala
 */
public class OnlineDatingSystem {

    /**
     * @param args the command line arguments
     */
    private static String loginName="";
    private static String loginId="";
    public static void main(String[] args) 
    {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        String selection ="";
        
        while(!selection.equals("x"))
        {
        System.out.println("****Welcome to Online Dating System******");
        System.out.println("");
        System.out.println("If you have account then enter 1 else enter 2 to signup or x to exit");
        System.out.println("1: login");
        System.out.println("2: SignUp");
        System.out.println("x: exit");
        
        selection = input.next();
            System.out.println();
            
            if(selection.equals("1"))
            {
                //login
                login();
            }
            else if(selection.equals("2"))
            {
                //signup
                signUp();
            }
            else
            {
                ;
            }
        }
        
    }
    public static void login()
    {
        boolean StartLogin =true;
        System.out.println("Please enter your login details: ");
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter your loginId:");
        String userId = input.next();
        System.out.println("Please enter your password");
        String password = input.next();
        final String URL= "jdbc:mysql://mis-sql.uhcl.edu/uppalaa9809";
        Connection conn= null;
        Statement stat = null;
        ResultSet rs = null;
         
        try
        {
            conn = DriverManager.getConnection(URL, "uppalaa9809", "1502561");
            stat = conn.createStatement();
            rs = stat.executeQuery("select * from onlinedating_user where userId = '"+ userId + "'");
             int x=0;
            while(rs.next())
            {
               x++;
               if(rs.getString("password").equals(password))
               {
                   System.out.println("*** login successful ***");
                   loginName = rs.getString("name");
                   loginId = rs.getString("userId");
                   loginAfterMenu.menu();
                   break;
               }
               else
               {
                   System.out.println("***Login failed***");
                   System.out.println("**Passwords didnot match try to login or sign up again**");
                   System.out.println();
                   System.out.println("1: login");
                   System.out.println("2: SignUp");
                   System.out.println("3: forgot password");
                   String  choice3=input.next();
                   if(choice3.equals("1"))
                   {
                       login();
                   }
                   else if(choice3.equals("2"))
                   {
                       signUp();
                       
                      
                   }
                   else if(choice3.equals("3"))
                   {
                       forgottenPassword.forgottenPassword();
                   }
             
               }
            } 
            if(x==0)
            {
                System.out.println("***LOGIN FAILED***");
                System.out.println("***Passwords didnot match..try again to login or signUp***"); 
                 System.out.println("1: login");
                   System.out.println("2: SignUp");
                   if(input.next().equals("1"))
                   {
                       login();
                   }
                   else
                   {
                       signUp();
                       
                   }
            }
        }
        catch(SQLException e)
                {
                    e.printStackTrace();
                }
        finally
        {
            try
            {
                conn.close();
                 rs.close();
                stat.close();
               
            }
            catch(SQLException e)
                    {
                        e.printStackTrace();
                    }
        }
    }
    
    public static void signUp()
    {
        
        System.out.println("Please enter your details to signUp");
        Scanner input = new Scanner(System.in);
        String userId="";
        String password="";
        String name="";
        String gender="";
        String city="";
        String interest1="";
       String interest2="";
       String interest3="";
        int age=0;
        boolean ageflag =false;
        
        
        do
        {
       
        System.out.println("Create your Username: (must be less than 20 charachters)");
        userId = input.next();
        System.out.println("create your password: ");
         password = input.next();
         
         System.out.println("Please enter your Name: (must be less than 20 charachters)");
        name = input.next();
        System.out.println("Please enter your gender: (M/F) ");
         gender = input.next();
        System.out.println("Please enter your age: ");
        int ageEntered = input.nextInt();
        age = 0;
        if(ageEntered>=18)
        {
            age = age + ageEntered;
            
        }
        else
        {
            System.out.println("Your age must be atleast 18 to signup this system");
            ageflag= false;
           break;
        }
         int Key = 1;
        System.out.println("Please enter your city: ");
        city = input.next();
        System.out.println("Please enter your interest1");   
        interest1 = input.next();
        System.out.println("Please enter your interest2");  
        interest2 = input.next();
        System.out.println("Please enter your interest3");  
        interest3 = input.next();
            System.out.println("Security questions for retreiving password: ");
            forgottenPassword.newUser();
        break;
         }while(ageflag == false);
        
        final String  URL = "jdbc:mysql://mis-sql.uhcl.edu/uppalaa9809";    
        Connection conn = null;
        ResultSet rs =null;
        Statement stat = null;
        try
        {
            conn = DriverManager.getConnection(URL, "uppalaa9809", "1502561");
            stat = conn.createStatement();
            rs = stat.executeQuery("select * from onlineDating_user");
            int rowId = 1;
            while(rs.next())
            {
                rowId++;
            }
            int r = stat.executeUpdate("Insert into onlineDating_user values(" +rowId+ ", '" +userId+ "', '"+ password + "', '"+ name + "', '"+ 
                                       gender + "', '" + age + "', '" + city + "', '" + interest1 + "', '" + interest2 +"', '" 
                                      + interest3 +"','not yet login',0)");
         
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                conn.close();
                rs.close();
                stat.close();
                
            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }
        }
                
    }
    
    
    public static String getLoginName() {
        return loginName;
    }

    public static String getLoginId() {
        return loginId;
    }
}
