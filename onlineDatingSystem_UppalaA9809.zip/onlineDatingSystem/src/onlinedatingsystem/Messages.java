/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onlinedatingsystem;
import java.util.*;
import java.sql.*;
import java.text.*;

/**
 *
 * @author Ashish Uppala
 */
public class Messages {
    public static void Messages()
    {
       // System.out.println("Under Construction");
        Scanner input =new Scanner(System.in);
        System.out.println("***Message MEnu***");
        System.out.println("1: Send Message");
        System.out.println("2: Inbox");
        System.out.println("3: Sent Items");
        System.out.println("4: Go to your profile");
        System.out.println("5: logout");
        System.out.println("____________________________________________________________");
        String MenuChoice = input.next();
        
        if(MenuChoice.equals("1"))
        {
            //Inbox;
            Messages.SendMessage();
        }
        else if(MenuChoice.equals("2"))
        {
            //Outbox;
           Messages.viewInbox();
        }
        else if(MenuChoice.equals("3"))
        {
            //Sent Items
            Messages.sentItems();
        }
        else if(MenuChoice.equals("4"))
        {
            //going to your menu
            loginAfterMenu.menu();
        }
        else if(MenuChoice.equals("5"))
        {
            //logout
            logout.logout();
        }
        else
        {
           System.out.println("Your have selected wrong choice");
            System.out.println();
            System.out.println("*** Returning to mesage menu***");
            System.out.println();
            Messages.Messages();
            System.out.println("------------------------------------");
        }
    }
    
    public static void SendMessage()
    {
        System.out.println("****Welcome to your inbox***");
        Scanner   input = new Scanner(System.in);
         final String URL = "jdbc:mysql://mis-sql.uhcl.edu/uppalaa9809";
        Connection conn = null;
        ResultSet  rs = null;
         Statement stat = null;
        String userId = OnlineDatingSystem.getLoginId();
        
        try 
        {
            conn = DriverManager.getConnection(URL, "uppalaa9809", "1502561");
            stat = conn.createStatement();
            System.out.println("--------------");
            System.out.println("Sender's ID : ");
            System.out.println(userId);
            System.out.println();
            System.out.println("Receiver's ID : ");
            String receiverId = input.next();
            String msgInput = "";
            rs = stat.executeQuery("Select * from onlinedating_user where userId= '" +receiverId+ "'");
            boolean idCheck = false;
            while( rs.next())
                    {
                                idCheck = true;
                }
            if(idCheck = true)
            {
                boolean msglength = true;
                int line = 0;
                do
                {
                    line++;
                    System.out.println("enter your message upto 150 characters in a single line only");
                    msgInput = msgInput + input.nextLine();
                    if(line==2)
                    {
                        break;
                    }
                }while(input.hasNextLine());
                
                if(msgInput.length() >149)
                {
                    msglength = false;
                }
                else
                {
                    ;
                }
                if(msglength==true)
                {
                    System.out.println("select any one of the following options to proceed");
                    System.out.println("1: Send");
                    System.out.println("2: Discard");
                    System.out.println();
                    String sendoption = input.next();
                    if(sendoption.equals("1"))
                    {
                        System.out.println("***your message is sent successfully***");
                        String dateAndTime = DateAndTime.DateTime();
                       int r = stat.executeUpdate("Insert into onlinedating_message values('" +userId+ "', '" +receiverId+"', '"
                                                                                   +msgInput+"', '" +dateAndTime+ "')");
                        System.out.println();
                        
                        Messages.messagesentmenu();
                      
                    }
                    else if(sendoption.equals("2"))
                    {
                        System.out.println("your message is discarded and returning to message menu");
                        Messages.Messages();
                    }
                    else
                    {
                        System.out.println("***unprovided option returning to message menu***");
                        Messages.Messages();
                    }
                     
                }
            }
            else
            {
                System.out.println("***no id is present***");
                System.out.println("*** returning to message menu***");
                Messages.Messages();
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                conn.close();
                rs.close();
                stat.close();
            }
            catch(SQLException e)
                    {
                        e.printStackTrace();
                    }
        }
        
     }
    public static void viewInbox()
    {
        Scanner input = new Scanner(System.in);
        final String URL = "jdbc:mysql://mis-sql.uhcl.edu/uppalaa9809";
        Connection conn = null;
        ResultSet  rs = null;
        Statement stat = null;
        String userId = OnlineDatingSystem.getLoginId();
        
        try
        {
            conn = DriverManager.getConnection(URL, "uppalaa9809", "1502561");
            stat = conn.createStatement();
            
            rs = stat.executeQuery("Select * from onlineDating_message where ReceiverId= '" +userId+ "'");
            boolean msgchk = false;
            while(rs.next())
            {
                msgchk = true;
                 System.out.println("Received from (Sender's ID): " + rs.getString("senderID"));
              System.out.println("Received At: "+ rs.getString("dateAndTime"));
              System.out.println("Message");
              System.out.println("-------");
              System.out.println(rs.getString("message"));
              System.out.println();
            }
            if (msgchk = false)
            {
                System.out.println("There  are no messages");
                Messages.Messages();
            }
        }
        catch(SQLException e)
                {
                    e.printStackTrace();
                }
        finally
        {
            try
            {
                conn.close();
                rs.close();
                stat.close();
            }
            catch(SQLException e)
                    {
                        e.printStackTrace();
                    }
        }
    }
    public static void sentItems()
    {
         Scanner input = new Scanner(System.in);
        final String URL = "jdbc:mysql://mis-sql.uhcl.edu/uppalaa9809";
        Connection conn = null;
        ResultSet  rs = null;
        Statement stat = null;
        String userId = OnlineDatingSystem.getLoginId();
        
        try
        {
            conn = DriverManager.getConnection(URL, "uppalaa9809", "1502561");
            stat = conn.createStatement();
            
            rs = stat.executeQuery("Select * from onlineDating_message where senderId= '" +userId+ "'");
            boolean msgchk = false;
            while(rs.next())
            {
                msgchk = true;
                 System.out.println("sent to: " + rs.getString("receiverId"));
              System.out.println("sent At: "+ rs.getString("dateAndTime"));
              System.out.println("Message");
              System.out.println("-------");
              System.out.println(rs.getString("message"));
              System.out.println();
            }
            if (msgchk = false)
            {
                System.out.println("There  are no messages");
                Messages.Messages();
            }
        }
        catch(SQLException e)
                {
                    e.printStackTrace();
                }
        finally
        {
            try
            {
                conn.close();
                rs.close();
                stat.close();
            }
            catch(SQLException e)
                    {
                        e.printStackTrace();
                    }
        }
    }
    
    public static void messagesentmenu()
    {
                         System.out.println("***MENU***");
                        System.out.println("1:send message again");
                        System.out.println("2: go back to message menu");
                        System.out.println("3: go back to main menu");
                        System.out.println("4: logout");
                        Scanner input = new Scanner(System.in);
                        String choice3 =input.next();
                        if(choice3.equals("1"))
                        {
                            Messages.SendMessage();
                        }
                        else if(choice3.equals("2"))
                        {
                            Messages.Messages();
                        }
                        else if(choice3.equals("3"))
                        {
                            loginAfterMenu.menu();
                        }
                        else if(choice3.equals("4"))
                        {
                            logout.logout();
                        }
                        else
                        {
                             System.out.println("your message is discarded and returning to message menu");
                        Messages.Messages(); 
                        }
    }
}
