/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onlinedatingsystem;
import java.util.*;
import java.sql.*;
import java.text.*;
/**
 *
 * @author Ashish Uppala
 */
public class profileView 
{
 public static void profileView()
 {
   Scanner input = new Scanner(System.in);
     System.out.println("1:Enter the ID to view Profile");
     System.out.println("2:Enter the name to view profile");
     System.out.println("3:Enter to view top 3 Males and top 3 Females: ");
     
     String viewChoice =input.next();
     String userId = OnlineDatingSystem.getLoginId();
     final String URL = "jdbc:mysql://mis-sql.uhcl.edu/uppalaa9809";
     Connection conn =null;
     ResultSet rs=null;
    
     Statement stat=null;
     Statement stat1=null;
     int viewUpdate = 0;
     try
     {  
         conn=DriverManager.getConnection(URL, "uppalaa9809", "1502561");
         stat = conn.createStatement();
     stat1 = conn.createStatement();
    
     if(viewChoice.equals("1"))
     {
         System.out.println("Please enter the ID to view Profile");
         String viewID = input.next();
         rs = stat.executeQuery("select * from onlinedating_user where userId='"+viewID+"'");
          int x=0;
         while(rs.next())
         {
             if(!rs.getString("userId").equals(userId))
             {
             x++;
             System.out.println("userId="+ " "+rs.getString("userId"));
            System.out.println("name="+ " "+rs.getString("name"));
            System.out.println("gender="+ " "+rs.getString("gender"));
            System.out.println("age="+ " "+rs.getString("age"));
            System.out.println("city="+" " +rs.getString("city"));
            System.out.println("interest1="+ " "+rs.getString("interest1"));
            System.out.println("interest2="+ " "+rs.getString("interest2"));
            System.out.println("interest3="+ " "+rs.getString("interest3"));
            System.out.println("lastlogindateandtime="+ " "+rs.getString("logoffTime"));
            viewUpdate = rs.getInt("views") + 1;
           int r =stat1.executeUpdate("Update  onlinedating_user set views='"+viewUpdate+"' where userId='"+viewID+"'");
             System.out.println("views are"+" "+viewUpdate);
             }
         }
         if(x==0)
         {
             System.out.println("you have no friends. so returning to your menu");
             loginAfterMenu.menu();
         }
     }
     else if(viewChoice.equals("2"))
     {
         System.out.println("Please enter the name to view Profile");
         String viewName = input.next();
         rs = stat.executeQuery("select * from onlinedating_user where name='"+viewName+"'");
         int x=0;
         while(rs.next())
         {
             x++;
             System.out.println("userId="+ " "+rs.getString("userId"));
            System.out.println("name="+ " "+rs.getString("name"));
            System.out.println("gender="+ " "+rs.getString("gender"));
            System.out.println("age="+ " "+rs.getString("age"));
            System.out.println("city="+" " +rs.getString("city"));
            System.out.println("interest1="+ " "+rs.getString("interest1"));
            System.out.println("interest2="+ " "+rs.getString("interest2"));
            System.out.println("interest3="+ " "+rs.getString("interest3"));
            System.out.println("lastlogindateandtime="+ " "+rs.getString("logoffTime"));
             viewUpdate = rs.getInt("views") + 1;
          int r =stat1.executeUpdate("Update  onlinedating_user set views='"+viewUpdate+"' where name='"+viewName+"'");
             System.out.println("views are"+" "+rs.getString("views"));
             
         }
          if(x==0)
         {
             System.out.println("you have no friends. so returning to your menu");
             loginAfterMenu.menu();
         }
     }
     else if(viewChoice.equals("3"))
     {
         System.out.println("M: for male");
         System.out.println("F: for female");
         String top = input.next();
         rs = stat1.executeQuery(" Select * from onlinedating_user where gender= 'M' order  by views desc limit 3 ");
         rs = stat1.executeQuery("Select * from onlinedating_user where gender = 'F' order by views desc limit 3");
         while(rs.next())
         {
         if(top.equals("M"))
         {
            
            System.out.println("userId="+ " "+rs.getString("userId"));
            System.out.println("name="+ " "+rs.getString("name"));
            System.out.println("gender="+ " "+rs.getString("gender"));
            System.out.println("age="+ " "+rs.getString("age"));
            System.out.println("views are"+" "+rs.getString("views"));;
                   
         
         }
         else if(top.equals("F"))
         {
             
             
            System.out.println("userId="+ " "+rs.getString("userId"));
            System.out.println("name="+ " "+rs.getString("name"));
            System.out.println("gender="+ " "+rs.getString("gender"));
            System.out.println("age="+ " "+rs.getString("age"));
            System.out.println("views are"+" "+rs.getString("views"));;
                   
           
         }
           else
             {
                 profileView.profileView();
             }
         }
     }
     }
     catch(SQLException e)
             {
                 e.printStackTrace();
             }
     finally
     {
         try
         {
             conn.close();
             rs.close();
             
             stat.close();
             stat1.close();
         }
         catch(SQLException e)
                 {
                     e.printStackTrace();
                 }
     }
 }
}





