/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onlinedatingsystem;
import java.util.*;
import java.sql.*;
import java.text.*;
/**
 *
 * @author Ashish Uppala
 */
public class FriendsList 
{
  public static void  FriendsList()
  {
      Scanner input = new Scanner(System.in);
      System.out.println("*********Welcome to your friendsList" +OnlineDatingSystem.getLoginName() +"**********");
      System.out.println("");
      System.out.println("");
      System.out.println("*** you can check your friend***");
      System.out.println("1:view your friend's list and status of the requests");
      System.out.println("2: Do you want to change the status of any of your friend");
      System.out.println("3: check your friends profile");
      System.out.println("4: Do you want to send message");
       System.out.println("5: view only friends List");
      System.out.println("6: enter to login after menu");
     
      String menuChoice = input.next();
      final String URL="jdbc:mysql://mis-sql.uhcl.edu/uppalaa9809";
      Connection conn =null;
      ResultSet rs =null;
      ResultSet rs1 =null;
      Statement stat =null;
      Statement stat1=null;
      String receiverId = OnlineDatingSystem.getLoginId();
      try
      {
         conn =DriverManager.getConnection(URL, "uppalaa9809", "1502561");
         stat = conn.createStatement();
         stat1 =conn.createStatement();
         rs1=stat1.executeQuery("select distinct friendId from onlinedating_friendsList where friendId!='"+receiverId+ "'" );
         rs =stat.executeQuery("select distinct senderId, Status from onlinedating_friendrequest where receiverId='" +receiverId+ "'");
         if(menuChoice.equals("1"))
         {
         while(rs.next())
         {
             System.out.println( "Sender's ID is"+" "+rs.getString("senderId")+ "and status is"+" " + rs.getString("Status"));
             System.out.println();
         }
         FriendsList.FriendsList();
         }
         
         else if(menuChoice.equals("2"))
         {
          System.out.println("Do you want to change the status of any of your friend's (Y/N)");
          String StatusChange= input.next();
          if(StatusChange.equals("Y"))
          {
              pendingFriendRequest.pendingFriendRequest();
          }
          else if(StatusChange.equals("N"))
          {
              //returning to friends list menu
              System.out.println("returning to friend's list menu");
              FriendsList.FriendsList();
          }
          else
          {
              System.out.println("Please enter correct choice");
          }
         }
         else if(menuChoice.equals("3"))
         {
             profileView.profileView();
         }
         else if(menuChoice.equals("4"))
         {
             Messages.Messages();
         }
           else if(menuChoice.equals("6"))
         {
             loginAfterMenu.menu();
         }
           else if(menuChoice.equals("5"))
           {
               while(rs1.next())
               {
               System.out.println(rs1.getString("friendId"));
               }
           }
         else
         {
             System.out.println("Please enter correct choice from 1-6 only");
         }
         
      }
      catch(SQLException e)
              {
                  e.printStackTrace();
              }
      finally
      {
          try
          {
              conn.close();
              rs.close();
              rs1.close();
              stat.close();
              stat1.close();
          }
          catch(SQLException e)
                  {
                      e.printStackTrace();
                  }
      }
  }
}
